﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ChatClient
{
    static class Program
    {
        //Start Program
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            try
            {
                Application.Run(new CSCI_4300_Message_System());
            }
            catch(Exception e)
            {
                MessageBox.Show(e.ToString(), "MAIN LOOP");
            }
        }
    }
}
