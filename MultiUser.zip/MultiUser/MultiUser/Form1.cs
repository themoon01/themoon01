﻿//Matthew Moon
//CSCI 4300
//Project
//November 26 2022


using System;
using System.Net.Sockets;
using System.Text;
using System.Windows.Forms;

namespace ChatClient
{

    public partial class CSCI_4300_Message_System : Form
    {

        /// WinSock sockets.
        TcpClient _client;

        /// Buffer to store messages
        byte[] _buffer = new byte[4096];

        public CSCI_4300_Message_System()
        {
            InitializeComponent();
            _client = new TcpClient();
        }

        //Start up connect as form starts
        protected override void OnShown(EventArgs e)
        {
            base.OnShown(e);

            // Connect to server with IP address and port #
            _client.Connect("10.0.0.19", 54000);

            // Start reading the socket and receive any incoming messages
            _client.GetStream().BeginRead(_buffer, 0, _buffer.Length, Server_MessageReceived, null);
        }

        //listens for incoming messages
        private void Server_MessageReceived(IAsyncResult ar)
        {
            if (ar.IsCompleted)
            {
                // End the stream read
                var bytesIn = _client.GetStream().EndRead(ar);
                if (bytesIn > 0)
                {
                    // turns stream of bytes into string type
                    var tmp = new byte[bytesIn];
                    Array.Copy(_buffer, 0, tmp, 0, bytesIn);
                    var str = Encoding.ASCII.GetString(tmp);

                    // using threads print message to message box
                    BeginInvoke((Action)(() =>
                    {
                        listBox1.Items.Add(str);
                        listBox1.SelectedIndex = listBox1.Items.Count - 1;
                    }));
                }

                // Clear the buffer and start listening again
                Array.Clear(_buffer, 0, _buffer.Length);
                _client.GetStream().BeginRead(_buffer, 0, _buffer.Length, Server_MessageReceived, null);
            }
        }

        //Sends message on button click
        private void button1_Click(object sender, EventArgs e)
        {
            // turns stream of bytes into string type and send it out to the server.
            var msg = Encoding.ASCII.GetBytes(textBox1.Text);
            if (msg.Length >= 5)
            {   if ((msg[0] == '\\') && (msg[1] == 'E' || msg[1] == 'e') && (msg[2] == 'X' || msg[2] == 'x') && (msg[3] == 'I' || msg[3] == 'i') && (msg[4] == 'T' || msg[4] == 't'))
                { this.Close(); }}
            _client.GetStream().Write(msg, 0, msg.Length);

            // reset text box
            textBox1.Text = "";
            textBox1.Focus();
        }
    }
}
